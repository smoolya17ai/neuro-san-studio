Some of these classes come from evolution-service/esp_service/logging.
They are intended to be exactly the same as ESP uses until we can get
a consolidated code base for the 3 services (ENN uses them too).
